import sys, socket

def client(server_addr):
    sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(server_addr)
    money = 1000
    while True:
        print 'StepUp, how much want to bet?(%s)'%(money)
        message = sys.stdin.readline() #��
        sock.send(message) #��
        while True:
            print 'StepUp, hit, stand?'
            message1=sys.stdin.readline() #h, s
            sock.send(message1)
            if message1 == 'h\n':
                card = sock.recv(1024)
                print ("BJCards() = %s" %(card))
            #'card = sock.recv(1024) '
            if message1 == 's\n':
                money = sock.recv(1024)
                print ("money:", int(money)-int(message))
                
                break
            #'print card' #�츮 ��
    sock.close()
    print 'close'
    
if __name__=='__main__':
    client(('localhost', 1039))
